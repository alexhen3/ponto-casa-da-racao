import { useEffect, useState, useCallback } from 'react'
import { supabase } from './supabase'
import Admin from './Admin.jsx'

const TIPOS = ['entrada', 'saida_intervalo', 'retorno', 'saida']
const ROTULO = { entrada: 'Registrar entrada', saida_intervalo: 'Sair para intervalo', retorno: 'Voltar do intervalo', saida: 'Encerrar expediente' }
const NOME = { entrada: 'Entrada', saida_intervalo: 'Saída intervalo', retorno: 'Retorno', saida: 'Saída' }
const hhmm = (d) => new Date(d).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', timeZone: 'America/Fortaleza' })
const fmt = (ms) => `${Math.floor(ms / 36e5)}h ${String(Math.floor((ms % 36e5) / 6e4)).padStart(2, '0')}min`

// Soma os períodos trabalhados; período aberto conta até agora.
export function horasTrabalhadas(regs, agora = Date.now()) {
  let total = 0, inicio = null
  for (const r of regs) {
    const t = new Date(r.registrado_em).getTime()
    if (r.tipo === 'entrada' || r.tipo === 'retorno') inicio = t
    else if (inicio !== null) { total += t - inicio; inicio = null }
  }
  return inicio !== null ? total + (agora - inicio) : total
}

function pegarLocalizacao() {
  return new Promise((ok, erro) => {
    if (!navigator.geolocation) return erro(new Error('Este aparelho não suporta localização.'))
    navigator.geolocation.getCurrentPosition(ok, (e) => erro(new Error(
      e.code === 1 ? 'Permissão de localização negada. Ative o GPS para este site nas configurações do navegador.'
      : 'Não foi possível obter a localização. Vá para um local aberto e tente novamente.')),
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 })
  })
}

function Login() {
  const [email, setEmail] = useState(''), [senha, setSenha] = useState(''), [msg, setMsg] = useState(''), [load, setLoad] = useState(false)
  async function entrar(e) {
    e.preventDefault(); setLoad(true); setMsg('')
    const { error } = await supabase.auth.signInWithPassword({ email, password: senha })
       if (error) setMsg(error.message)
    setLoad(false)
  }
  return (
    <main className="login">
      <form onSubmit={entrar} className="login-box">
        <h1>Ponto</h1>
        <p className="mut">Entre com o e-mail e a senha fornecidos pela empresa.</p>
        <label>E-mail<input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required autoComplete="username" /></label>
        <label>Senha<input type="password" value={senha} onChange={(e) => setSenha(e.target.value)} required autoComplete="current-password" /></label>
        {msg && <p className="erro" role="alert">{msg}</p>}
        <button className="btn" disabled={load}>{load ? 'Entrando…' : 'Entrar'}</button>
      </form>
    </main>
  )
}

function Funcionario({ perfil }) {
  const [regs, setRegs] = useState([]), [agora, setAgora] = useState(Date.now()), [msg, setMsg] = useState(null), [busy, setBusy] = useState(false)
  const carregar = useCallback(async () => {
    const ini = new Date(); ini.setHours(0, 0, 0, 0)
    const { data } = await supabase.from('time_records').select('*').gte('registrado_em', ini.toISOString()).order('registrado_em')
    setRegs(data || [])
  }, [])
  useEffect(() => { carregar(); const i = setInterval(() => setAgora(Date.now()), 1000); return () => clearInterval(i) }, [carregar])

  const prox = TIPOS[regs.length]
  async function marcar() {
    setBusy(true); setMsg(null)
    try {
      const p = await pegarLocalizacao()
      const { error } = await supabase.rpc('registrar_ponto', { p_lat: p.coords.latitude, p_lng: p.coords.longitude, p_precisao: p.coords.accuracy })
      if (error) throw new Error(error.message)
      setMsg({ ok: true, t: 'Ponto registrado com sucesso.' }); await carregar()
    } catch (e) { setMsg({ ok: false, t: e.message }) }
    setBusy(false)
  }

  return (
    <section className="painel">
      <p className="mut">Olá, {perfil.nome}</p>
      <div className="relogio">{new Date(agora).toLocaleTimeString('pt-BR', { timeZone: 'America/Fortaleza' })}</div>
      <p className="mut">{new Date(agora).toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long', timeZone: 'America/Fortaleza' })}</p>
      {prox ? <button className="btn grande" onClick={marcar} disabled={busy}>{busy ? 'Obtendo localização…' : ROTULO[prox]}</button>
            : <p className="ok-dia">Expediente de hoje concluído.</p>}
      {msg && <p className={msg.ok ? 'ok' : 'erro'} role="status">{msg.t}</p>}
      <div className="resumo"><span className="mut">Trabalhado hoje</span><strong>{fmt(horasTrabalhadas(regs, agora))}</strong></div>
      <ul className="lista">
        {TIPOS.map((t, i) => (
          <li key={t} className={regs[i] ? 'feito' : ''}><span>{NOME[t]}</span><span>{regs[i] ? hhmm(regs[i].registrado_em) : '—'}</span></li>
        ))}
      </ul>
    </section>
  )
}

function Escolha({ perfil, escolher }) {
  return (
    <main className="login">
      <div className="login-box">
        <h1>Olá, {perfil.nome}</h1>
        <p className="mut">Como você quer entrar agora?</p>
        <button className="btn" onClick={() => escolher('admin')}>Painel do administrador</button>
        <button className="btn sec" onClick={() => escolher('ponto')}>Registrar meu ponto</button>
        <button className="link" onClick={() => supabase.auth.signOut()}>Sair</button>
      </div>
    </main>
  )
}

export default function App() {
  const [sessao, setSessao] = useState(undefined), [perfil, setPerfil] = useState(null), [modo, setModo] = useState(null)
  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setSessao(data.session))
    const { data } = supabase.auth.onAuthStateChange((_e, s) => setSessao(s))
    return () => data.subscription.unsubscribe()
  }, [])
  useEffect(() => {
    if (!sessao) { setPerfil(null); setModo(null); return }
    supabase.from('profiles').select('*').eq('id', sessao.user.id).single().then(({ data }) => setPerfil(data))
  }, [sessao])

  if (sessao === undefined) return null
  if (!sessao) return <Login />
  if (!perfil) return <p className="mut centro">Carregando…</p>
  if (!perfil.ativo) return <p className="erro centro">Seu acesso está desativado. Fale com o administrador.</p>

  const admin = perfil.role === 'admin'
  if (admin && !modo) return <Escolha perfil={perfil} escolher={setModo} />

  return (
    <>
      <header className="topo">
        <strong>Ponto</strong>
        <div className="acoes">
          {admin && <button className="link" onClick={() => setModo(modo === 'admin' ? 'ponto' : 'admin')}>{modo === 'admin' ? 'Ir para meu ponto' : 'Ir para o painel'}</button>}
          <button className="link" onClick={() => supabase.auth.signOut()}>Sair</button>
        </div>
      </header>
      {admin && modo === 'admin' ? <Admin eu={perfil.id} /> : <Funcionario perfil={perfil} />}
    </>
  )
}
