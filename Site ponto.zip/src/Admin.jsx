import { useEffect, useState, useCallback } from 'react'
import { createClient } from '@supabase/supabase-js'
import { supabase } from './supabase'
import './admin.css'

const NOME = { entrada: 'Entrada', saida_intervalo: 'Saída intervalo', retorno: 'Retorno', saida: 'Saída' }
const dh = (d) => new Date(d).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit', timeZone: 'America/Fortaleza' })
const VAZIO = { nome: '', email: '', senha: '', cargo: '' }

function Funcionarios({ eu }) {
  const [lista, setLista] = useState([]), [f, setF] = useState(VAZIO), [msg, setMsg] = useState(null), [busy, setBusy] = useState(false)
  const carregar = useCallback(async () => {
    const { data } = await supabase.from('profiles').select('*').order('nome'); setLista(data || [])
  }, [])
  useEffect(() => { carregar() }, [carregar])
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value })

  async function criar(e) {
    e.preventDefault(); setBusy(true); setMsg(null)
    // cliente temporário: cria o login sem deslogar o administrador
    const tmp = createClient(import.meta.env.VITE_SUPABASE_URL, import.meta.env.VITE_SUPABASE_ANON_KEY, { auth: { persistSession: false, autoRefreshToken: false } })
    const { data, error } = await tmp.auth.signUp({ email: f.email, password: f.senha, options: { data: { nome: f.nome } } })
    if (error || !data.user) setMsg({ ok: false, t: error?.message || 'Não foi possível criar o funcionário.' })
    else {
      await supabase.from('profiles').update({ cargo: f.cargo }).eq('id', data.user.id)
      setMsg({ ok: true, t: `${f.nome} cadastrado. Ele já pode entrar com o e-mail e a senha informados.` }); setF(VAZIO); carregar()
    }
    setBusy(false)
  }
  async function alternar(p) { await supabase.from('profiles').update({ ativo: !p.ativo }).eq('id', p.id); carregar() }
  async function editar(p) {
    const nome = window.prompt('Nome:', p.nome); if (nome === null) return
    const cargo = window.prompt('Cargo:', p.cargo || ''); if (cargo === null) return
    await supabase.from('profiles').update({ nome, cargo }).eq('id', p.id); carregar()
  }

  return (
    <>
      <form className="cad" onSubmit={criar}>
        <h2>Novo funcionário</h2>
        <label>Nome<input value={f.nome} onChange={set('nome')} required /></label>
        <label>Cargo<input value={f.cargo} onChange={set('cargo')} /></label>
        <label>E-mail de login<input type="email" value={f.email} onChange={set('email')} required /></label>
        <label>Senha (mínimo 6 caracteres)<input type="text" minLength={6} value={f.senha} onChange={set('senha')} required /></label>
        <button className="btn" disabled={busy}>{busy ? 'Salvando…' : 'Cadastrar funcionário'}</button>
        {msg && <p className={msg.ok ? 'ok' : 'erro'} role="status">{msg.t}</p>}
      </form>
      <h2>Equipe</h2>
      <ul className="lista eq">
        {lista.map((p) => (
          <li key={p.id} className={p.ativo ? '' : 'off'}>
            <div><strong>{p.nome}</strong>{p.role === 'admin' && ' (admin)'}<div className="mut">{p.cargo || 'Sem cargo'} · {p.email}</div></div>
            <div className="acoes">
              <button className="link" onClick={() => editar(p)}>Editar</button>
              {p.id !== eu && <button className="link" onClick={() => alternar(p)}>{p.ativo ? 'Desativar' : 'Reativar'}</button>}
            </div>
          </li>
        ))}
      </ul>
    </>
  )
}

function Registros() {
  const [regs, setRegs] = useState(null)
  useEffect(() => {
    const ini = new Date(Date.now() - 7 * 864e5).toISOString()
    supabase.from('time_records').select('*, profiles(nome)').gte('registrado_em', ini).order('registrado_em', { ascending: false }).limit(200)
      .then(({ data }) => setRegs(data || []))
  }, [])
  if (!regs) return <p className="mut">Carregando…</p>
  if (!regs.length) return <p className="mut">Nenhuma marcação nos últimos 7 dias.</p>
  return (
    <div className="rolar"><table>
      <thead><tr><th>Funcionário</th><th>Tipo</th><th>Data e hora</th><th>Local</th></tr></thead>
      <tbody>{regs.map((r) => (
        <tr key={r.id}><td>{r.profiles?.nome}</td><td>{NOME[r.tipo]}</td><td>{dh(r.registrado_em)}</td>
          <td>{r.lat != null ? <a target="_blank" rel="noreferrer" href={`https://www.openstreetmap.org/?mlat=${r.lat}&mlon=${r.lng}#map=18/${r.lat}/${r.lng}`}>Ver no mapa ({Math.round(r.precisao)} m)</a> : '—'}</td></tr>
      ))}</tbody>
    </table></div>
  )
}

export default function Admin({ eu }) {
  const [aba, setAba] = useState('func')
  return (
    <section className="painel larga">
      <nav className="abas">
        <button className={aba === 'func' ? 'on' : ''} onClick={() => setAba('func')}>Funcionários</button>
        <button className={aba === 'reg' ? 'on' : ''} onClick={() => setAba('reg')}>Registros</button>
      </nav>
      {aba === 'func' ? <Funcionarios eu={eu} /> : <Registros />}
    </section>
  )
}
